package com.example.firstapp;

public class Std
{
    public String Stdid;
    public String Stdname;
    public String course;

    public Std()
    {
    }

    public Std(String stdid, String stdname, String course) {
        Stdid = stdid;
        Stdname = stdname;
        this.course = course;
    }
}




