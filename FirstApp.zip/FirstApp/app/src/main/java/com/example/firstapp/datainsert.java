package com.example.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class datainsert extends AppCompatActivity {
    EditText data_email, data_pass;
    Button btn_add;
    DatabaseReference databaseReference = FirebaseDatabase
            .getInstance("https://firstapp-4043d-default-rtdb.asia-southeast1.firebasedatabase.app/").
                    getReference("Student");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datainsert);
        data_email = findViewById(R.id.data_email);
        data_pass = findViewById(R.id.data_pass);
        btn_add = findViewById(R.id.btn_add);
        btn_add.setOnClickListener(view -> {
        String id = System.currentTimeMillis()+"";
        Std std = new Std(id,data_email.getText().toString(),data_pass.getText().toString());
            databaseReference.child(id).setValue(std);
            Toast.makeText(datainsert.this, "Inserted", Toast.LENGTH_SHORT).show();
        });
    }
}